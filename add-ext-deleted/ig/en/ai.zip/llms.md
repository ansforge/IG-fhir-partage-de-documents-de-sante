# ans.fhir.fr.pdsm#3.1.1: Partage de Documents de Santé en mobilité (PDSm)(en)

## Pages

* [Accueil](index.md)
* [Historique des changements](changes.md)
* [Mise à jour de documents](sf_maj.md)
* [Spécifications techniques - vue d'ensemble](construction_des_flux.md)
* [Mise à jour de documents](st_maj.md)
* [Consultation de documents](sf_consultation.md)
* [Recherche de lot de soumission (ITI-66)](st_recherche_lot.md)
* [Artifacts Summary](artifacts.md)
* [Recherche de documents](sf_recherche.md)
* [Ajout d'un lot de documents](sf_ajout.md)
* [Publication simplifiée d'un document](sf_publication_simplifiee.md)
* [Ajout d'un lot de documents (ITI-65)](st_ajout.md)
* [Téléchargements et usages](downloads.md)
* [Autres Ressources](autres_ressources.md)
* [Spécifications fonctionnelles - vue d'ensemble](specifications_fonctionnelles.md)
* [Recherche de fiche (ITI-67)](st_recherche_fiche.md)
* [Equivalences](equivalences.md)
* [Publication simplifiée d'un document (ITI-105)](st_publication_simplifiee.md)
* [Sécurité](securite.md)
* [Consultation de documents (ITI-68)](st_consultation.md)

## Resources

### Resource Profiles

* [PDSm Comprehensive DocumentReference](StructureDefinition-pdsm-comprehensive-document-reference.md)
* [PDSm Comprehensive Provide Document Bundle](StructureDefinition-pdsm-comprehensive-provide-document-bundle.md)
* [PDSm Find DocumentReferences Comprehensive Response](StructureDefinition-pdsm-find-documentreferences-comprehensive-response.md)
* [PDSm Find Lists Response](StructureDefinition-pdsm-find-lists-response.md)
* [PDSm Folder Comprehensive](StructureDefinition-pdsm-folder-comprehensive.md)
* [PDSm Simplified Publish Document Reference](StructureDefinition-pdsm-simplified-publish.md)
* [PDSm SubmissionSet Comprehensive](StructureDefinition-pdsm-submissionset-comprehensive.md)

### Extensions

* [PDSm_intendedRecipient](StructureDefinition-pdsm-ext-intended-recipient.md)
* [PDSm_isArchived](StructureDefinition-pdsm-ext-is-archived.md)

### CapabilityStatements

* [CI-SIS Partage-De-Documents-De-Sante - ConsommateurDeDocuments](CapabilityStatement-PDSm-ConsommateurDeDocuments.md)
* [CI-SIS Partage-De-Documents-De-Sante - GestionnaireDePartageDeDocuments](CapabilityStatement-PDSm-GestionnaireDePartageDeDocuments.md)
* [CI-SIS Partage-De-Documents-De-Sante - ProducteurDeDocuments](CapabilityStatement-PDSm-ProducteurDeDocuments.md)

### ImplementationGuides

* [Partage de Documents de Santé en mobilité (PDSm)](ImplementationGuide-ans.fhir.fr.pdsm.md)

### SearchParameters

* [PDSmDocumentReferencePeriodEnd](SearchParameter-PDSm-DocumentReference-period-end.md)
* [PDSmDocumentReferencePeriodStart](SearchParameter-PDSm-DocumentReference-period-start.md)
* [PDSmListPatientAsSource](SearchParameter-PDSm-List-PatientAsSource.md)
* [PDSmListPractitionerRoleAsSource](SearchParameter-PDSm-List-PractitionerRoleAsSource.md)
* [PDSmAuthorOrg](SearchParameter-PDSm-List-authorOrg.md)
* [PDSmIsArchived](SearchParameter-PDSm-isArchived.md)

### Examples

* [6789 (Binary)](Binary-6789.md)
* [a9c10f8a-882d-4000-a280-7150e0aeb478 (Bundle)](Bundle-a9c10f8a-882d-4000-a280-7150e0aeb478.md)
* [PDSmSimplifiedExample (DocumentReference)](DocumentReference-PDSmSimplifiedExample.md)
* [exemple-pdsm-documentreference (DocumentReference)](DocumentReference-exemple-pdsm-documentreference.md)
* [Classeur de suivi diabète (List)](List-ExampleFolder.md)
* [Dossier de suivi post-opératoire (List)](List-ExampleSubmissionSet.md)
* [HOPITAL INTERCOMMUNAL DE LA PRESQU'ILE G (Organization)](Organization-org-example.md)
* [fr-patient-123 (Patient)](Patient-fr-patient-123.md)
