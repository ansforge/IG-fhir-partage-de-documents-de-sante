# Specifications Techniques - Partage de Documents de Santé en mobilité (PDSm) v3.1.1

* [**Table of Contents**](toc.md)
* **Specifications Techniques**

## Specifications Techniques

