# practitioner-example - Partage de Documents de Santé en mobilité (PDSm) v3.1.1

## Example Practitioner: practitioner-example



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "practitioner-example",
  "meta" : {
    "lastUpdated" : "2025-04-28T18:19:26.335+02:00",
    "source" : "https://annuaire.sante.fr",
    "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-practitioner",
    "https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-practitioner"]
  },
  "language" : "fr",
  "extension" : [{
    "extension" : [{
      "url" : "type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://mos.esante.gouv.fr/NOS/TRE_R87-TypeCarte/FHIR/TRE-R87-TypeCarte",
          "code" : "CPS"
        }]
      }
    },
    {
      "url" : "number",
      "valueString" : "3100345668"
    },
    {
      "url" : "period",
      "valuePeriod" : {
        "start" : "2024-02-21",
        "end" : "2027-02-21"
      }
    }],
    "url" : "https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-smartcard"
  }],
  "identifier" : [{
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
        "code" : "IDNPS"
      }]
    },
    "system" : "urn:oid:1.2.250.1.71.4.2.1",
    "value" : "810101201234"
  },
  {
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-v2-0203",
        "code" : "RPPS"
      }]
    },
    "system" : "https://rpps.esante.gouv.fr",
    "value" : "10101201234"
  }],
  "active" : true,
  "name" : [{
    "text" : "Leclerc Sophie",
    "family" : "Leclerc",
    "given" : ["Sophie"],
    "prefix" : ["MME"],
    "suffix" : ["DR"]
  }],
  "telecom" : [{
    "extension" : [{
      "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-contact-point-email-type",
      "valueCoding" : {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R256-TypeMessagerie/FHIR/TRE-R256-TypeMessagerie",
        "code" : "MSSANTE",
        "display" : "MSSANTE"
      }
    },
    {
      "extension" : [{
        "url" : "type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "https://mos.esante.gouv.fr/NOS/TRE_R257-TypeBAL/FHIR/TRE-R257-TypeBAL",
            "code" : "PER"
          }]
        }
      },
      {
        "url" : "digitization",
        "valueBoolean" : false
      }],
      "url" : "https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-mailbox-mss-metadata"
    }],
    "system" : "email",
    "value" : "sophie.leclerc@mssante.fr",
    "use" : "work"
  }],
  "qualification" : [{
    "code" : {
      "coding" : [{
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R14-TypeDiplome/FHIR/TRE-R14-TypeDiplome",
        "code" : "DE"
      },
      {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R48-DiplomeEtatFrancais/FHIR/TRE-R48-DiplomeEtatFrancais",
        "code" : "DE11"
      }]
    }
  },
  {
    "code" : {
      "coding" : [{
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_R09-CategorieProfessionnelle/FHIR/TRE-R09-CategorieProfessionnelle",
        "code" : "C"
      },
      {
        "system" : "https://mos.esante.gouv.fr/NOS/TRE_G15-ProfessionSante/FHIR/TRE-G15-ProfessionSante",
        "code" : "70"
      }]
    }
  }]
}

```
